create procedure insertUserStatus()
  BEGIN

	DECLARE userid int;

	DECLARE done INT DEFAULT FALSE;

	DECLARE cur_user_list CURSOR FOR SELECT DISTINCT KU_ID FROM WK_T_USERBASEINFO; 

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

	OPEN cur_user_list;
			
	read_loop:LOOP

	FETCH cur_user_list INTO userid;

			IF done THEN
					LEAVE read_loop;
			END IF;

	insert into WK_T_USERBASEINFO (KU_ID,KU_TYPE,KU_VALUE) VALUE(userid,'WEEK_SUBCRIBE_STATUS',0);
END LOOP;
CLOSE cur_user_list;
END;

